package com.example.ceylonMart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CeylonMartApplicationTests {

	@Test
	void contextLoads() {
	}

}
